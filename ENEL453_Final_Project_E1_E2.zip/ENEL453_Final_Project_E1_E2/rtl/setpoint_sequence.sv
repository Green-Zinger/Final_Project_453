`timescale 1ns / 1ps
//==============================================================================
// Module: setpoint_sequence   (Enhancement E2: automatic setpoint sequence)
//
// Purpose
//   btnU starts and stops a fixed sequence of setpoints. Each setpoint is held
//   for HOLD_MS (2 s), long enough for the disk to settle, then the next one
//   is loaded. After the last one the sequence starts again from the first,
//   until btnU is pressed again. LD10 is on while it runs.
//
// The sequence (SEQ_OFFSETS in disk_pkg, in encoder COUNTS, easy to change)
//   step   offset   angle (from the start)
//    0      +512     +90 deg
//    1     +1024    +180 deg
//    2      +256     +45 deg
//    3        +0       0 deg   (back to where it started)
//   The offsets are added to the setpoint the disk had when btnU was pressed
//   (base). So the sequence always runs near the disk's current position and
//   never asks for a move of several revolutions. Counts, not degrees: 90
//   counts would be only 15.8 deg.
//
// Decisions (Final handout, 3.1)
//   - Start/stop on the EDGE of btnU, not its level. A press lasts about
//     100 ms = 10 million clock cycles; using the level would start and stop
//     the sequence millions of times.
//   - The hold timer is RESTARTED when the sequence starts. Otherwise the
//     first setpoint would be held for a random time (whatever was left on
//     the counter).
//   - Hold time from CLK_FREQ, divided first: (CLK_FREQ / 1000) x HOLD_MS =
//     100,000 x 2,000 = 2 x 10^8 cycles, which fits in a 32-bit int.
//     CLK_FREQ x HOLD_MS = 2 x 10^11 would overflow it. The closed-loop
//     testbench runs at 1 MHz and gets 2 s too.
//   - While it runs, btnR and btnL are ignored (setpoint_control's load
//     input). When it stops, the setpoint HOLDS its last value: no jump, and
//     btnR/btnL step on from there.
//   - Reset (btnC) stops it.
//
// Block diagram
//
//   start_stop --+------------>[AND]--> pressed --> running <= ~running
//                +--[reg]--[NOT]-^          |
//                                           +--> start: base <= setpoint_now,
//                                                index <= 0, restart timer
//   [ downcounter HOLD_CYCLES, enable = running ]--> hold_done --> index + 1
//                                                                  (wraps to 0)
//   base + SEQ_OFFSETS[index] --> sequence_setpoint   running --> load, LD10
//
// Parameters
//   CLK_FREQ : clock frequency, Hz. Default 100 MHz.
//   HOLD_MS  : time each setpoint is held, ms. Default 2,000.
//
// Inputs
//   clk, reset   : 100 MHz clock; synchronous active-high reset
//   start_stop   : debounced btnU level (1 while held)
//   setpoint_now : the current setpoint, counts (captured as base on start)
//
// Outputs
//   running           : 1 while the sequence runs (to LD10 and to load)
//   sequence_setpoint : the setpoint the sequence wants now, counts
//
// Internal signals
//   last, pressed : btnU one clock earlier; rising edge of btnU
//   start         : pressed while stopped (begin a new run)
//   hold_done     : one-cycle pulse every HOLD_MS while running
//   index         : which step of the sequence, 0 ... SEQ_LENGTH-1
//   base          : setpoint when the sequence started, counts
//
// Clocking: one system clock; reset is synchronous and active high.
//==============================================================================

module setpoint_sequence
    import disk_pkg::*;
#(
    parameter int CLK_FREQ = CLK_FREQ_HZ,
    parameter int HOLD_MS  = SEQ_HOLD_MS
) (
    input  logic                             clk,
    input  logic                             reset,
    input  logic                             start_stop,
    input  logic signed [POSITION_WIDTH-1:0] setpoint_now,
    output logic                             running,
    output logic signed [POSITION_WIDTH-1:0] sequence_setpoint
);

    // Divide first: CLK_FREQ x HOLD_MS would overflow a 32-bit int.
    localparam int HOLD_CYCLES = (CLK_FREQ / 1000) * HOLD_MS;   // 2 x 10^8
    localparam int INDEX_WIDTH = (SEQ_LENGTH > 1) ? $clog2(SEQ_LENGTH) : 1;

    logic last, pressed, start, hold_done;
    logic [INDEX_WIDTH-1:0] index;
    logic signed [POSITION_WIDTH-1:0] base;

    // Rising edge of btnU.
    assign pressed = start_stop && !last;
    assign start   = pressed && !running;

    // Hold timer: restarted when the sequence starts, counts only while running.
    downcounter #(
        .PERIOD(HOLD_CYCLES)          // 2 s
    ) HOLD_TIMER (
        .clk(clk),                    // system clock
        .reset(reset || start),       // restart with each new run
        .enable(running),             // count only while running
        .zero(hold_done)              // one pulse per hold time
    );

    always_ff @(posedge clk) begin
        if (reset) begin
            last    <= 1'b0;
            running <= 1'b0;
            index   <= '0;
            base    <= '0;
        end else begin
            last <= start_stop;
            if (pressed) begin
                running <= !running;                 // start or stop
                if (!running) begin                  // starting a new run
                    index <= '0;
                    base  <= setpoint_now;
                end
            end else if (running && hold_done) begin
                index <= (index == INDEX_WIDTH'(SEQ_LENGTH - 1)) ? '0 : index + 1'b1;
            end
        end
    end

    // Table lookup: base + offset (counts).
    assign sequence_setpoint = base + POSITION_WIDTH'(SEQ_OFFSETS[index]);

endmodule
