`timescale 1ns / 1ps
//==============================================================================
// Module: input_conditioning_subsystem
// Purpose
//   Synchronize asynchronous inputs and debounce the two step buttons.
// Block diagram
//   raw switches/encoder/reset -> synchronizers; step buttons -> debouncers
// Inputs
//   clk; reset_button; step_up_button, step_down_button; kp_switches;
//   arm_switch; counts_switch (sw[10]); ch_a, ch_b: raw board inputs
//   mode_switches (sw[9:8], E1 display mode); sequence_button (btnU, E2)
// Outputs
//   reset; step_up, step_down; kp; arm; counts_mode; encoder_a, encoder_b
//   display_mode (E1, synchronized); sequence_pressed (E2, debounced btnU)
// Internal signals
//   Synchronizer stages and debounce counters belong to their child modules.
// Clocking: one system clock; reset is synchronous and active high.
//==============================================================================
module input_conditioning_subsystem
    import disk_pkg::*;
#(
    parameter int CLK_FREQ = CLK_FREQ_HZ,
    parameter int DEBOUNCE_MS = DEBOUNCE_TIME_MS
) (
    input logic clk, reset_button, step_up_button, step_down_button,
    input logic [KP_WIDTH-1:0] kp_switches,
    input logic [DISPLAY_MODE_WIDTH-1:0] mode_switches,
    input logic arm_switch, counts_switch, sequence_button, ch_a, ch_b,
    output logic reset, step_up, step_down,
    output logic [KP_WIDTH-1:0] kp,
    output logic [DISPLAY_MODE_WIDTH-1:0] display_mode,
    output logic arm, counts_mode, sequence_pressed, encoder_a, encoder_b
);
    // Reset button. The synchronizer has no reset of its own, so it can
    // synchronize the reset button itself.
    synchronizer #(
        .WIDTH(1)
    ) RESET_SYNC (
        .clk(clk),                    // system clock
        .d(reset_button),             // btnC, asynchronous
        .q(reset)                     // synchronized reset for the whole design
    );

    // Encoder channel A.
    synchronizer #(
        .WIDTH(1)
    ) ENCODER_A_SYNC (
        .clk(clk),                    // system clock
        .d(ch_a),                     // encoder channel A, from Pmod JB1
        .q(encoder_a)                 // synchronized channel A
    );

    // Encoder channel B.
    synchronizer #(
        .WIDTH(1)
    ) ENCODER_B_SYNC (
        .clk(clk),                    // system clock
        .d(ch_b),                     // encoder channel B, from Pmod JB2
        .q(encoder_b)                 // synchronized channel B
    );

    // Gain switches, all four bits in one synchronizer.
    synchronizer #(
        .WIDTH(KP_WIDTH)               // 4 switches
    ) KP_SYNC (
        .clk(clk),                    // system clock
        .d(kp_switches),              // sw[3:0]
        .q(kp)                        // synchronized gain, 0 to 15
    );

    // Arm switch.
    synchronizer #(
        .WIDTH(1)
    ) ARM_SYNC (
        .clk(clk),                    // system clock
        .d(arm_switch),               // sw[15]
        .q(arm)                       // synchronized: 1 = motor allowed to run
    );

    synchronizer #(.WIDTH(1)) COUNTS_SYNC (
        .clk(clk), .d(counts_switch), .q(counts_mode)
    );

    // E1: display mode switches, both bits in one synchronizer.
    synchronizer #(
        .WIDTH(DISPLAY_MODE_WIDTH)    // 2 switches
    ) MODE_SYNC (
        .clk(clk),                    // system clock
        .d(mode_switches),            // sw[9:8]
        .q(display_mode)              // synchronized display mode
    );

    // E2: sequence start/stop button (btnU), debounced like btnR and btnL.
    debounce #(
        .CLK_FREQ(CLK_FREQ),          // system clock frequency, Hz
        .STABLE_TIME_MS(DEBOUNCE_MS)  // button must be steady this long
    ) SEQUENCE_DEBOUNCE (
        .clk(clk),                    // system clock
        .reset(reset),                // synchronous reset
        .button(sequence_button),     // raw btnU
        .result(sequence_pressed)     // debounced: 1 while held
    );

    // Step-up button (btnR).
    debounce #(
        .CLK_FREQ(CLK_FREQ),          // system clock frequency, Hz
        .STABLE_TIME_MS(DEBOUNCE_MS)  // button must be steady this long
    ) STEP_UP_DEBOUNCE (
        .clk(clk),                    // system clock
        .reset(reset),                // synchronous reset
        .button(step_up_button),      // raw btnR
        .result(step_up)              // debounced: 1 while held
    );

    // Step-down button (btnL).
    debounce #(
        .CLK_FREQ(CLK_FREQ),          // system clock frequency, Hz
        .STABLE_TIME_MS(DEBOUNCE_MS)  // button must be steady this long
    ) STEP_DOWN_DEBOUNCE (
        .clk(clk),                    // system clock
        .reset(reset),                // synchronous reset
        .button(step_down_button),    // raw btnL
        .result(step_down)            // debounced: 1 while held
    );


endmodule
