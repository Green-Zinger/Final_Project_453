`timescale 1ns / 1ps
//==============================================================================
// Module: angle_display_subsystem
// Purpose
//   Select what to show (E1 display modes), convert to BCD, and scan the
//   four-digit display.
// Block diagram
//   position, setpoint, command, counts_mode, display_mode
//      -> display_mode_select (E1) -> bin_to_bcd -> seven_segment_display
// Inputs
//   clk, reset; position, setpoint: signed counts; counts_mode: sw[10]
//   display_mode: sw[9:8] (E1); command: signed motor command (E1 mode 11)
// Outputs
//   degrees_bcd: selected value as BCD (name retained for test compatibility);
//   CA..CG, DP: active-low segments; AN1..AN4: active-low anodes
// Internal signals
//   display_value: selected magnitude; digit_blank: dark digits;
//   minus: E1 minus sign in the leftmost digit
// Clocking: one system clock; reset is synchronous and active high.
//==============================================================================
module angle_display_subsystem
    import disk_pkg::*;
(
    input logic clk, reset, counts_mode,
    input logic [DISPLAY_MODE_WIDTH-1:0] display_mode,
    input logic signed [POSITION_WIDTH-1:0] position, setpoint,
    input logic signed [COMMAND_WIDTH-1:0] command,
    output logic [15:0] degrees_bcd,
    output logic CA, CB, CC, CD, CE, CF, CG, DP,
    output logic AN1, AN2, AN3, AN4
);
    logic [15:0] display_value;
    logic [3:0] digit_blank;
    logic minus;

    // E1: choose the value (mode 00 is the MVP's display_selection, unchanged).
    display_mode_select DISPLAY_MODE_SELECT (
        .clk(clk),                    // system clock
        .reset(reset),                // synchronous reset
        .mode(display_mode),          // sw[9:8]
        .counts_mode(counts_mode),    // sw[10], mode 00 only
        .position(position),          // angle, counts
        .setpoint(setpoint),          // setpoint, counts
        .command(command),            // motor command, -255 ... +255
        .display_value(display_value),// magnitude to show
        .digit_blank(digit_blank),    // dark digits
        .minus(minus)                 // minus sign in the leftmost digit
    );

    bin_to_bcd BIN_TO_BCD (
        .clk(clk),                    // system clock
        .reset(reset),                // synchronous reset
        .bin_in(display_value),        // selected degrees or raw count
        .bcd_out(degrees_bcd)         // four BCD digits, e.g. 0359
    );

    seven_segment_display_subsystem SEVEN_SEGMENT_DISPLAY (
        .clk(clk),                    // system clock
        .reset(reset),                // synchronous reset
        .digit1(degrees_bcd[3:0]),    // ones of selected value (rightmost)
        .digit2(degrees_bcd[7:4]),    // tens of selected value
        .digit3(degrees_bcd[11:8]),   // hundreds of selected value
        .digit4(degrees_bcd[15:12]),  // thousands: enabled in counts mode
        .decimal_point(4'b0000),      // no decimal points
        .digit_blank(digit_blank),    // dark digits (leftmost un-blanked for "-")
        .minus_sign(minus),           // E1: "-" in the leftmost digit
        .CA(CA),                      // segment outputs (active low)
        .CB(CB),
        .CC(CC),
        .CD(CD),
        .CE(CE),
        .CF(CF),
        .CG(CG),
        .DP(DP),                      // decimal point output (active low)
        .AN1(AN1),                    // anode outputs (active low)
        .AN2(AN2),
        .AN3(AN3),
        .AN4(AN4)
    );


endmodule
