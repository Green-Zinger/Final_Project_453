`timescale 1ns / 1ps
//==============================================================================
// Module: position_control_subsystem
// Purpose
//   Decode position, update the button setpoint, and sample the P controller.
//   Final project (E2): a setpoint sequence on btnU can take over the setpoint.
// Block diagram
//   encoder -> decoder -> position; buttons -> setpoint -> P -> command
// Inputs
//   clk, reset; encoder_a, encoder_b: synchronized; step_up/down: debounced; kp
//   sequence_pressed: debounced btnU (E2: start/stop the sequence)
// Outputs
//   position, setpoint: signed encoder counts; command: signed, limited to +/-255
//   sequence_running: 1 while the E2 sequence runs (LD10)
// Internal signals
//   control_tick: clock enable every CLK_FREQ / CTRL_FREQ cycles
//   sequence_setpoint: the setpoint the E2 sequence wants (loaded while running)
// Clocking: one system clock; reset is synchronous and active high.
//==============================================================================
module position_control_subsystem
    import disk_pkg::*;
#(
    parameter int CLK_FREQ = CLK_FREQ_HZ,
    parameter int CTRL_FREQ = CONTROL_FREQ_HZ
) (
    input logic clk, reset, encoder_a, encoder_b, step_up, step_down,
    input logic [KP_WIDTH-1:0] kp,
    input logic sequence_pressed,
    output logic signed [POSITION_WIDTH-1:0] position, setpoint,
    output logic signed [COMMAND_WIDTH-1:0] command,
    output logic sequence_running
);
    logic signed [POSITION_WIDTH-1:0] sequence_setpoint;
    localparam int CTRL_PERIOD = CLK_FREQ / CTRL_FREQ;
    logic control_tick;
    // 100 Hz pulse: tells the controller when to take a sample.
    downcounter #(
        .PERIOD(CTRL_PERIOD)          // 1,000,000 cycles = 10 ms
    ) CONTROL_TICK_GEN (
        .clk(clk),                    // system clock
        .reset(reset),                // synchronous reset
        .enable(1'b1),                // always counting
        .zero(control_tick)           // one-cycle pulse every 10 ms
    );

    // Measure: encoder channels -> position in counts.
    quad_decoder QUAD_DECODER (
        .clk(clk),                    // system clock
        .reset(reset),                // synchronous reset: position = 0
        .a(encoder_a),                // synchronized channel A
        .b(encoder_b),                // synchronized channel B
        .position(position)           // signed position, counts
    );

    // E2: btnU runs a fixed sequence of setpoints, 2 s each.
    setpoint_sequence #(
        .CLK_FREQ(CLK_FREQ),          // hold time computed from the clock
        .HOLD_MS(SEQ_HOLD_MS)         // 2,000 ms per setpoint
    ) SETPOINT_SEQUENCE (
        .clk(clk),                    // system clock
        .reset(reset),                // synchronous reset: stopped
        .start_stop(sequence_pressed),// debounced btnU
        .setpoint_now(setpoint),      // captured as the base when it starts
        .running(sequence_running),   // 1 while running (LD10)
        .sequence_setpoint(sequence_setpoint) // base + table entry, counts
    );

    // Setpoint: +/-90 degrees per button press, or the sequence while it runs.
    setpoint_control SETPOINT_CONTROL (
        .clk(clk),                    // system clock
        .reset(reset),                // synchronous reset: setpoint = 0
        .step_up(step_up),            // debounced btnR
        .step_down(step_down),        // debounced btnL
        .load(sequence_running),      // E2: the sequence owns the setpoint
        .load_value(sequence_setpoint), // E2: setpoint from the sequence
        .setpoint(setpoint)           // desired position, counts
    );

    // Compare: command = Kp x (setpoint - position), limited to +/-255.
    // p_controller knows nothing about the disk (it is written to be reused
    // unchanged, for example inside a PI controller), so the disk's sizes and
    // limits are given to it here, as parameters.
    p_controller #(
        .IN_WIDTH(POSITION_WIDTH),    // setpoint and position: 16 bits
        .KP_WIDTH(KP_WIDTH),          // kp: 4 bits, 0 to 15
        .FRAC_BITS(0),                // Kp is a whole number
        .OUT_WIDTH(COMMAND_WIDTH),    // command: 9 bits
        .OUT_MAX(COMMAND_MAX),        // +255: full power forward
        .OUT_MIN(-COMMAND_MAX)        // -255: full power reverse
    ) P_CONTROLLER (
        .clk(clk),                    // system clock
        .reset(reset),                // synchronous reset: command = 0
        .sample_tick(control_tick),   // update 100 times per second
        .reference(setpoint),         // desired position, counts
        .measured(position),          // measured position, counts
        .kp(kp),                      // gain from sw[3:0]
        .error(),                     // setpoint - position: not needed here
        .p_action(command)            // -255 (full reverse) to +255 (full forward)
    );


endmodule
