`timescale 1ns / 1ps
//==============================================================================
// Module: status_led_subsystem
// Purpose
//   Map synchronized status and motor direction to the existing LED layout.
// Block diagram
//   kp, encoder_a/b, sequence_running, arm, motor_in1/2 -> fixed wiring -> led[15:0]
// Inputs
//   kp; encoder_a, encoder_b; sequence_running (E2); arm; motor_in1, motor_in2
// Outputs
//   led: Kp[3:0], A[8], B[9], sequence running[10] (E2), reverse[13],
//        forward[14], armed[15]
// Internal signals
//   None: combinational wiring only; no clock or reset is needed.
// Clocking: combinational only; no state, clock, or reset.
//==============================================================================
module status_led_subsystem
    import disk_pkg::*;
(
    input logic [KP_WIDTH-1:0] kp,
    input logic encoder_a, encoder_b, sequence_running, arm, motor_in1, motor_in2,
    output logic [15:0] led
);
    assign led[3:0]   = kp;           // gain Kp, in binary
    assign led[7:4]   = 4'b0000;      // unused
    assign led[8]     = encoder_a;    // encoder channel A (flickers when turning)
    assign led[9]     = encoder_b;    // encoder channel B (flickers when turning)
    assign led[10]    = sequence_running; // E2: LD10 on while the sequence runs
    assign led[12:11] = 2'b00;        // unused
    assign led[13]    = motor_in2;    // motor driving in reverse
    assign led[14]    = motor_in1;    // motor driving forward
    assign led[15]    = arm;          // motor armed


endmodule
