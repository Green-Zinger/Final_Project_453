`timescale 1ns / 1ps
//==============================================================================
// Module: display_selection
//
// Purpose
//   Select the binary value and digit blanking for the disk display. This is
//   combinational logic; counts_mode must already be synchronized to clk.
//
// Block diagram
//   position --> position_to_degrees --+--> mux --> display_value
//            \--> low REV_BITS -------+     ^
//                                     counts_mode --> digit_blank
//
// Inputs
//   position      : signed encoder position, in counts
//   counts_mode   : 0 = degrees, 1 = encoder counts within one revolution
// Outputs
//   display_value : unsigned binary value for bin_to_bcd (0..359 or 0..2047)
//   digit_blank   : 1000 in degrees mode; 0000 in counts mode
// Internal signals
//   degrees       : wrapped angle from the existing conversion module
//   count_in_rev  : low REV_BITS of position; modulo COUNTS_PER_REV
//
// COUNTS_PER_REV must be a power of two, as in position_to_degrees. With 2048
// counts, low 11 bits of -1 are 11'b11111111111 = 2047. A 500-line encoder
// would need a different modulo implementation in both modules.
//==============================================================================
module display_selection
    import disk_pkg::*;
(
    input  logic signed [POSITION_WIDTH-1:0] position,
    input  logic counts_mode,
    output logic [15:0] display_value,
    output logic [3:0] digit_blank
);
    localparam int REV_BITS = $clog2(COUNTS_PER_REV);
    logic [DEGREES_WIDTH-1:0] degrees;
    logic [REV_BITS-1:0] count_in_rev;

    position_to_degrees POSITION_TO_DEGREES (
        .position(position), .degrees(degrees)
    );
    assign count_in_rev = position[REV_BITS-1:0];
    assign display_value = counts_mode ? 16'(count_in_rev) : 16'(degrees);
    assign digit_blank = counts_mode ? 4'b0000 : 4'b1000;
endmodule
