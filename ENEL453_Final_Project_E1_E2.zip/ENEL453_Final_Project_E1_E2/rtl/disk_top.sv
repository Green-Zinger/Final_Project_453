`timescale 1ns / 1ps
//==============================================================================
// Module: disk_top
// Purpose: structural top level for the Basys3 spinning-disk position loop.
// Block diagram
//   board -> INPUT_CONDITIONING -> POSITION_CONTROL -> MOTOR_INTERFACE -> motor
//                                      | position
//                                      +-> ANGLE_DISPLAY -> 7-segment display
//            synchronized status + motor direction -> STATUS_LEDS
// Inputs
//   clk: 100 MHz; reset_button: btnC; step_up/down_button: btnR/btnL
//   kp_switches: sw[3:0]; arm_switch: sw[15]; counts_switch: sw[10]
//   mode_switches: sw[9:8] (E1 display modes); sequence_button: btnU (E2)
//   ch_a, ch_b: asynchronous encoder channels from JB1 and JB2
// Outputs
//   motor_en, motor_in1, motor_in2: L298N ENB, IN3, IN4 on JC3, JC1, JC2
//   led[15:0]: gain, encoder and motor status
//   CA..CG, DP, AN1..AN4: active-low Basys3 display signals
// Internal signals
//   reset, encoder_a/b, kp, arm, counts_mode, display_mode: synchronized inputs
//   sequence_pressed: debounced btnU; sequence_running: E2 running (LD10)
//   step_up/down: debounced button levels
//   position/setpoint: signed counts; command: signed motor demand
//   degrees_bcd: selected display value in BCD, exposed for testbench inspection
// Every subsystem uses clk; slower actions use enables, never derived clocks.
// Parameters preserve the supplied timing overrides for tb_disk_top.
//==============================================================================
module disk_top
    import disk_pkg::*;
#(
    parameter int CLK_FREQ = CLK_FREQ_HZ,
    parameter int CTRL_FREQ = CONTROL_FREQ_HZ,
    parameter int PWM_FREQ = PWM_FREQ_HZ,
    parameter int DEBOUNCE_MS = DEBOUNCE_TIME_MS
) (
    input logic clk, reset_button, step_up_button, step_down_button,
    input logic [KP_WIDTH-1:0] kp_switches,
    input logic [DISPLAY_MODE_WIDTH-1:0] mode_switches,
    input logic arm_switch, counts_switch, sequence_button, ch_a, ch_b,
    output logic motor_en, motor_in1, motor_in2,
    output logic [15:0] led,
    output logic CA, CB, CC, CD, CE, CF, CG, DP,
    output logic AN1, AN2, AN3, AN4
);
    logic reset, encoder_a, encoder_b, arm, counts_mode, step_up, step_down;
    logic [KP_WIDTH-1:0] kp;
    logic [DISPLAY_MODE_WIDTH-1:0] display_mode;
    logic sequence_pressed, sequence_running;
    logic signed [POSITION_WIDTH-1:0] position, setpoint;
    logic signed [COMMAND_WIDTH-1:0] command;
    logic [15:0] degrees_bcd;

    input_conditioning_subsystem #(
        .CLK_FREQ(CLK_FREQ), .DEBOUNCE_MS(DEBOUNCE_MS)
    ) INPUT_CONDITIONING (
        .clk(clk), .reset_button(reset_button),
        .step_up_button(step_up_button), .step_down_button(step_down_button),
        .kp_switches(kp_switches), .arm_switch(arm_switch),
        .counts_switch(counts_switch), .mode_switches(mode_switches),
        .sequence_button(sequence_button), .ch_a(ch_a), .ch_b(ch_b),
        .reset(reset), .step_up(step_up), .step_down(step_down),
        .kp(kp), .arm(arm), .counts_mode(counts_mode),
        .display_mode(display_mode), .sequence_pressed(sequence_pressed),
        .encoder_a(encoder_a), .encoder_b(encoder_b)
    );
    position_control_subsystem #(
        .CLK_FREQ(CLK_FREQ), .CTRL_FREQ(CTRL_FREQ)
    ) POSITION_CONTROL (
        .clk(clk), .reset(reset), .encoder_a(encoder_a), .encoder_b(encoder_b),
        .step_up(step_up), .step_down(step_down), .kp(kp),
        .sequence_pressed(sequence_pressed),
        .position(position), .setpoint(setpoint), .command(command),
        .sequence_running(sequence_running)
    );
    motor_interface_subsystem #(
        .CLK_FREQ(CLK_FREQ), .PWM_FREQ(PWM_FREQ)
    ) MOTOR_INTERFACE (
        .clk(clk), .reset(reset), .arm(arm), .command(command),
        .motor_en(motor_en), .motor_in1(motor_in1), .motor_in2(motor_in2)
    );
    angle_display_subsystem ANGLE_DISPLAY (
        .clk(clk), .reset(reset), .counts_mode(counts_mode),
        .display_mode(display_mode), .position(position), .setpoint(setpoint),
        .command(command),
        .degrees_bcd(degrees_bcd),
        .CA(CA), .CB(CB), .CC(CC), .CD(CD), .CE(CE), .CF(CF), .CG(CG),
        .DP(DP), .AN1(AN1), .AN2(AN2), .AN3(AN3), .AN4(AN4)
    );
    status_led_subsystem STATUS_LEDS (
        .kp(kp), .encoder_a(encoder_a), .encoder_b(encoder_b),
        .sequence_running(sequence_running), .arm(arm),
        .motor_in1(motor_in1), .motor_in2(motor_in2), .led(led)
    );
endmodule
