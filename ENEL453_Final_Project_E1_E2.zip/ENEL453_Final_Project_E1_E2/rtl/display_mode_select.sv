`timescale 1ns / 1ps
//==============================================================================
// Module: display_mode_select   (Enhancement E1: display and debug modes)
//
// Purpose
//   Chooses what the four-digit display shows, from sw[9:8]:
//
//     mode  shows                                         example
//     ----  --------------------------------------------  -------
//      00   the MVP display, unchanged: the angle in        " 090"
//           degrees, or the count (0-2047) with sw[10] up   "1533"
//      01   the setpoint angle in degrees (0-359)           " 270"
//      10   the error, setpoint - angle, in degrees,        "-012"
//           minus sign when negative, limited to +/-999
//      11   the motor command as a percentage of full      "-047"
//           power, minus sign for reverse (0-100)
//
//   Every value is passed on as a SIGN and a MAGNITUDE, so bin_to_bcd only
//   ever receives a positive number. The minus sign is drawn in the leftmost
//   digit (which is otherwise blank in degrees modes); that digit is
//   un-blanked when, and only when, the minus sign is shown.
//
// Rounding (both checked for EVERY input value in tb_display_mode_select)
//   error in degrees  = round(|error| x 360 / 2048) = (|error| x 45 + 128) >> 8
//                       (360/2048 = 45/256 exactly; +128 = +0.5 before >> 8)
//   command percent   = round(|command| x 100 / 255) = (|command| x 25,700
//                       + 32,768) >> 16  (25,700 / 65,536 = 0.392151 ~ 100/255;
//                       exact for all 256 values, no divider needed)
//   The magnitude is rounded FIRST, then limited to 999, then the sign is
//   applied, so +x and -x always show the same digits. A magnitude that
//   rounds to 0 shows no minus sign ("-000" never appears).
//
// Block diagram
//
//   position, counts_mode -->[ display_selection (MVP) ]--> mode 00 --+
//   setpoint ---------------->[ position_to_degrees    ]--> mode 01 --+
//   setpoint - position --> |e| --> x45+128 >>8 --> limit 999 -> 10 --+-->[ mux ]--[reg]--> value,
//   command --> |cmd| --> x25700+32768 >>16 -------------------> 11 --+   sw[9:8]       digit_blank,
//                 signs ------------------------------------------------------------->   minus
//
// Pipeline registers (timing)
//   The products (|error| x 45, |command| x 25,700) are registered, and the
//   selected value is registered again. The instructor's reference display
//   modes failed timing by 1.1 ns without these. The display updates 2 clock
//   cycles (20 ns) late, which nobody can see.
//
// Inputs
//   clk, reset   : 100 MHz clock; synchronous active-high reset
//   mode         : sw[9:8], synchronized
//   counts_mode  : sw[10], synchronized (mode 00 only, as in the MVP)
//   position     : encoder position, signed counts
//   setpoint     : setpoint, signed counts
//   command      : motor command, signed, -255 ... +255
//
// Outputs
//   display_value: magnitude to show, binary, 0 ... 9999 (to bin_to_bcd)
//   digit_blank  : 1 = keep that digit dark (bit 3 = leftmost)
//   minus        : 1 = draw a minus sign in the leftmost digit
//
// Internal signals
//   error            : setpoint - position, signed 17 bits (never overflows)
//   error_mag        : |error|, 17 bits (up to 65,536)
//   error_scaled     : error_mag x 45 + 128, 23 bits (up to 2,949,248), registered
//   error_degrees    : error_scaled >> 8, then limited to 999
//   command_mag      : |command|, 8 bits (0 ... 255)
//   command_scaled   : command_mag x 25,700 + 32,768, 23 bits (up to 6,586,268), registered
//   command_percent  : command_scaled >> 16 (0 ... 100)
//   mvp_value, mvp_blank : mode 00, from the MVP's display_selection
//   setpoint_degrees : mode 01
//
// Clocking: one system clock; reset is synchronous and active high.
//==============================================================================

module display_mode_select
    import disk_pkg::*;
(
    input  logic                             clk,
    input  logic                             reset,
    input  logic [1:0]                       mode,
    input  logic                             counts_mode,
    input  logic signed [POSITION_WIDTH-1:0] position,
    input  logic signed [POSITION_WIDTH-1:0] setpoint,
    input  logic signed [COMMAND_WIDTH-1:0]  command,
    output logic [15:0]                      display_value,
    output logic [3:0]                       digit_blank,
    output logic                             minus
);

    localparam int ERR_WIDTH = POSITION_WIDTH + 1;                 // 17
    localparam int ERR_SCALED_WIDTH = 23;                          // 65,536 x 45 + 128 < 2^22
    localparam int CMD_SCALED_WIDTH = 23;                          // 255 x 25,700 + 32,768 < 2^23
    localparam int ERROR_LIMIT = 999;                              // +/-999 degrees

    logic signed [ERR_WIDTH-1:0]        error;
    logic        [ERR_WIDTH-1:0]        error_mag;
    logic        [ERR_SCALED_WIDTH-1:0] error_scaled;
    logic        [14:0]                 error_rounded;
    logic        [9:0]                  error_degrees;
    logic                               error_negative;
    logic        [DUTY_WIDTH-1:0]       command_mag;
    logic        [CMD_SCALED_WIDTH-1:0] command_scaled;
    logic        [6:0]                  command_percent;
    logic                               command_negative;
    logic        [15:0]                 mvp_value;
    logic        [3:0]                  mvp_blank;
    logic        [DEGREES_WIDTH-1:0]    setpoint_degrees;

    // Mode 00: the MVP's own selection logic, unchanged.
    display_selection MVP_DISPLAY (
        .position(position),          // encoder position, counts
        .counts_mode(counts_mode),    // sw[10]: degrees or counts
        .display_value(mvp_value),    // value the MVP showed
        .digit_blank(mvp_blank)       // blanking the MVP used
    );

    // Mode 01: the setpoint, converted exactly like the angle.
    position_to_degrees SETPOINT_TO_DEGREES (
        .position(setpoint),          // setpoint, counts
        .degrees(setpoint_degrees)    // 0 ... 359
    );

    // Mode 10 and 11: sign and magnitude. Both operands are signed, so the
    // subtraction is done at 17 bits and never overflows.
    assign error       = ERR_WIDTH'(setpoint) - ERR_WIDTH'(position);
    assign error_mag   = error[ERR_WIDTH-1] ? ERR_WIDTH'(-error) : ERR_WIDTH'(error);
    assign command_mag = command[COMMAND_WIDTH-1] ? DUTY_WIDTH'(-command)
                                                  : DUTY_WIDTH'(command);

    // Pipeline register 1: the scaling multiplies (and the signs, so they stay
    // in step with their magnitudes).
    always_ff @(posedge clk) begin
        if (reset) begin
            error_scaled     <= '0;
            command_scaled   <= '0;
            error_negative   <= 1'b0;
            command_negative <= 1'b0;
        end else begin
            error_scaled     <= ERR_SCALED_WIDTH'(error_mag) * 23'd45 + 23'd128;
            command_scaled   <= CMD_SCALED_WIDTH'(command_mag) * 23'd25700 + 23'd32768;
            error_negative   <= error[ERR_WIDTH-1];
            command_negative <= command[COMMAND_WIDTH-1];
        end
    end

    // Round first (the shifts), then limit the error to 999.
    assign error_rounded   = error_scaled[ERR_SCALED_WIDTH-1:8];       // 15 bits, <= 11,520
    assign error_degrees   = (error_rounded > 15'(ERROR_LIMIT)) ? 10'(ERROR_LIMIT)
                                                           : 10'(error_rounded);
    assign command_percent = command_scaled[CMD_SCALED_WIDTH-1:16];    // 0 ... 100

    // Pipeline register 2: select by mode. The minus sign is shown only for a
    // negative value whose rounded magnitude is not zero.
    always_ff @(posedge clk) begin
        if (reset) begin
            display_value <= '0;
            digit_blank   <= 4'b1000;
            minus         <= 1'b0;
        end else begin
            unique case (mode)
                2'b00: begin                                   // MVP display
                    display_value <= mvp_value;
                    digit_blank   <= mvp_blank;
                    minus         <= 1'b0;
                end
                2'b01: begin                                   // setpoint, degrees
                    display_value <= 16'(setpoint_degrees);
                    digit_blank   <= 4'b1000;
                    minus         <= 1'b0;
                end
                2'b10: begin                                   // error, degrees
                    display_value <= 16'(error_degrees);
                    minus         <= error_negative && (error_degrees != 0);
                    digit_blank   <= (error_negative && (error_degrees != 0))
                                     ? 4'b0000 : 4'b1000;      // un-blank for the sign
                end
                default: begin                                 // 2'b11: command, percent
                    display_value <= 16'(command_percent);
                    minus         <= command_negative && (command_percent != 0);
                    digit_blank   <= (command_negative && (command_percent != 0))
                                     ? 4'b0000 : 4'b1000;
                end
            endcase
        end
    end

endmodule
