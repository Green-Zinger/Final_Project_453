`timescale 1ns / 1ps
//==============================================================================
// Module: motor_interface_subsystem
// Purpose
//   Generate the PWM enable and convert signed command into L298N signals.
// Block diagram
//   clock -> PWM tick; command + arm + tick -> motor_drive -> L298N
// Inputs
//   clk, reset; arm: synchronized enable; command: signed motor demand
// Outputs
//   motor_en: PWM; motor_in1, motor_in2: direction; all off when disarmed
// Internal signals
//   pwm_tick: clock enable; PWM_TICK_PERIOD = CLK_FREQ / (PWM_FREQ * COMMAND_MAX)
// Clocking: one system clock; reset is synchronous and active high.
//==============================================================================
module motor_interface_subsystem
    import disk_pkg::*;
#(
    parameter int CLK_FREQ = CLK_FREQ_HZ,
    parameter int PWM_FREQ = PWM_FREQ_HZ
) (
    input logic clk, reset, arm,
    input logic signed [COMMAND_WIDTH-1:0] command,
    output logic motor_en, motor_in1, motor_in2
);
    localparam int PWM_TICK_PERIOD = CLK_FREQ / (PWM_FREQ * COMMAND_MAX);
    logic pwm_tick;
    // 2.56 MHz pulse: steps the PWM counter (255 steps = one 10 kHz period).
    downcounter #(
        .PERIOD(PWM_TICK_PERIOD)      // 39 cycles = 390 ns
    ) PWM_TICK_GEN (
        .clk(clk),                    // system clock
        .reset(reset),                // synchronous reset
        .enable(1'b1),                // always counting
        .zero(pwm_tick)               // one-cycle pulse every 39 cycles
    );

    // Drive: command -> L298N direction and PWM signals.
    motor_drive MOTOR_DRIVE (
        .clk(clk),                    // system clock
        .reset(reset),                // synchronous reset: motor off
        .arm(arm),                    // sw[15]: 0 forces the motor off
        .pwm_tick(pwm_tick),          // sets the PWM frequency
        .command(command),            // signed motor command
        .motor_en(motor_en),          // to L298N ENB (PWM)
        .motor_in1(motor_in1),        // to L298N IN3 (forward)
        .motor_in2(motor_in2)         // to L298N IN4 (reverse)
    );


endmodule
