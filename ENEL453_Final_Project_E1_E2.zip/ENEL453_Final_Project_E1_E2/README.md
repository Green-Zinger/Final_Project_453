# ENEL 453 Final Project: Spinning Disk, E1 + E2

Basys3 (Artix-7 xc7a35tcpg236-1) position control of the spinning disk. It starts from the team's MVP and adds two enhancements:

- **E2: setpoint sequence.** btnU starts and stops a fixed sequence: +90°, +180°, +45°, back to start, 2 s each, repeating. LD10 is on while it runs.
- **E1: display and debug modes.** sw[9:8] chooses what the display shows: 00 MVP angle · 01 setpoint · 10 error (with minus sign) · 11 motor command %.

Claimed for 4 marks: E2 (2) + E1 (2). `p_controller.sv` is unchanged from the MVP, as the project requires.

## Setup on your computer

You need **Vivado** (built with 2026.1; 2025.x should also work) and **Python 3** (only for the test runner).

1. **Get the files.** Clone the repository:
   ```
   git clone <this repository's URL>
   ```
   Or use GitHub's **Code → Download ZIP** and unzip it.

2. **Create the Vivado project.** Open Vivado. In the **Tcl Console** at the bottom, run (use your own path, with forward slashes):
   ```
   source C:/path/to/enel453-final-project/scripts/create_project.tcl
   ```
   This builds `vivado/Final_Project.xpr` inside the repo and opens it, with the design, constraints and all testbenches added. Next time, open that `.xpr` with **File → Open Project**.

3. **Generate the bitstream.** Use **Generate Bitstream** in the Flow Navigator. The result is `vivado/Final_Project.runs/impl_1/disk_top.bit`.

   **Shortcut:** `bitstream/disk_top.bit` is the tested E1 + E2 build (Nov 27, 2026). You can program it directly and skip steps 2–3.

4. **Program the board.** Keep **sw[15] down**. Use **Open Hardware Manager → Open Target → Auto Connect → Program Device**.

Re-running `create_project.tcl` deletes and recreates the `vivado/` folder. It's safe, because all the source files live outside it.

## Running the testbenches

All 10 are self-checking: each prints `PASS <name>` or `FAIL <name>`.

**From a terminal** (fastest, runs them all). In the repo folder:
```
python scripts/run_tests.py
```
- Results go to `evidence/final/summary.txt`.
- One testbench only: `python scripts/run_tests.py tb_setpoint_sequence`.
- If Vivado isn't found, set `VIVADO_BIN` to your Vivado `bin` folder, e.g. `C:/AMDDesignTools/2026.1/Vivado/bin`.

**In the Vivado GUI:**
1. Under Simulation Sources, right-click a testbench → **Set as Top**.
2. Run **Run Simulation → Run Behavioral Simulation**, then **Run All**.

`tb_disk_top` simulates 22 s of disk motion and takes about a minute.

| Testbench | Checks |
|---|---|
| `tb_disk_top` | Whole design + disk model: all MVP checks, then E1 modes and the E2 sequence on the closed loop |
| `tb_display_mode_select` | E1: every error magnitude and every command value against exact rounding (132,473 checks) |
| `tb_setpoint_sequence` | E2: start/stop edge, exact 2 s holds, wrap, restart, reset |
| `tb_p_controller`, `tb_quad_decoder`, `tb_motor_drive`, `tb_debounce`, `tb_bin_to_bcd`, `tb_position_to_degrees`, `tb_display_selection` | MVP modules |

## Board controls

| Control | Function |
|---|---|
| sw[3:0] | Kp in binary (use 2 = sw[1] only), shown on LD3–LD0 |
| sw[9:8] | E1 display mode: 00 MVP, 01 setpoint, 10 error, 11 command % |
| sw[10] | Counts mode (in display mode 00) |
| sw[15] | Arm the motor (LD15). **Down while programming and wiring.** |
| btnR / btnL | Setpoint +90° / −90° (ignored while the sequence runs) |
| btnU | E2: start / stop the sequence |
| btnC | Reset |
| LD10 | E2 sequence running |

## Repository layout

```
rtl/            design (top: disk_top.sv; constants: disk_pkg.sv)
                  E1: display_mode_select.sv (+ minus sign in seven_segment_decoder / _display_subsystem)
                  E2: setpoint_sequence.sv (+ load input in setpoint_control.sv)
tb/             self-checking testbenches
constraints/    disk_basys3.xdc (Basys3 pins; E1: sw[8] V2, sw[9] T3; E2: btnU T18)
scripts/        create_project.tcl, run_tests.py, build_bitstream.tcl (batch build to output/)
docs/           Design Record (E1_E2_Design_Record.md), block diagram, annotated waveforms
bitstream/      disk_top.bit, ready to program (zip only)
```

## Changing things

- **The sequence:** `SEQ_OFFSETS` in `rtl/disk_pkg.sv`, in encoder **counts** (2048 per revolution, so 512 = 90°). Keep `SEQ_LENGTH` equal to the number of entries.
- **Hold time:** `SEQ_HOLD_MS` in `rtl/disk_pkg.sv`.
- **Before pushing a change:** run `python scripts/run_tests.py`; all 10 must pass. Then rebuild and check that timing is still met (WNS > 0 in the Project Summary). An enhancement that breaks the MVP, a testbench or timing costs the whole project.

## Last results (Nov 27, 2026)

- **Simulation:** all 10 testbenches pass in Vivado xsim 2026.1.
- **Build:** 371 LUTs, 332 flip-flops, WNS +0.331 ns (timing met).
- **Demo:** Dec 4 (B02), in the lab period. Every member must attend in person.
