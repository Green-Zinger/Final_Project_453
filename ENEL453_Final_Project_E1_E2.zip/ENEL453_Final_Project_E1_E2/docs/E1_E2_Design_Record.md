# ENEL 453 Final Project — Enhancements E1 (Display and debug modes) and E2 (Setpoint sequence)

**Claimed enhancements (priority order):** 1. E2 Setpoint sequence (2 marks) · 2. E1 Display and debug modes (2 marks). Together: 4/4.

**Inputs and outputs (Table 1):**

| Control | Function |
|---|---|
| **sw[9:8]** | E1 display mode: 00 MVP, 01 setpoint, 10 error, 11 command % |
| **btnU** | E2: start / stop the sequence |
| **LD10** | E2: on while the sequence runs |
| unchanged MVP controls | Kp sw[3:0], arm sw[15], counts sw[10], btnR/btnL ±90°, btnC reset |

---

## Step 1 — Plan

![E1 + E2 block diagram](E1_E2_block_diagram.png)

`disk_top` still contains only instances and connections.
- E1 sits in `angle_display_subsystem` (new `display_mode_select`, minus sign added to the display).
- E2 sits in `position_control_subsystem` (new `setpoint_sequence`, a `load` input added to `setpoint_control`).
- The new inputs go through `input_conditioning_subsystem`: sw[9:8] through a synchronizer, btnU through a debouncer.

### New modules and ports

| Module | Port | Dir | Type | Meaning |
|---|---|---|---|---|
| **display_mode_select** (E1) | clk, reset | in | logic | 100 MHz clock, synchronous reset |
| | mode | in | [1:0] | sw[9:8], synchronized |
| | counts_mode | in | logic | sw[10] (mode 00 only) |
| | position, setpoint | in | signed [15:0] | counts |
| | command | in | signed [8:0] | −255 … +255 |
| | display_value | out | [15:0] | magnitude to show (to bin_to_bcd) |
| | digit_blank | out | [3:0] | dark digits |
| | minus | out | logic | draw "−" in the leftmost digit |
| **setpoint_sequence** (E2) | clk, reset | in | logic | |
| | start_stop | in | logic | debounced btnU level |
| | setpoint_now | in | signed [15:0] | captured as the base on start |
| | running | out | logic | to LD10 and setpoint_control.load |
| | sequence_setpoint | out | signed [15:0] | base + table entry |

**Changed modules**
- `setpoint_control`: new `load` and `load_value` inputs.
- `seven_segment_decoder`: new `minus` input.
- `seven_segment_display_subsystem`: new `minus_sign` input, applied to the leftmost digit only.
- `angle_display_subsystem`, `position_control_subsystem`, `input_conditioning_subsystem`, `status_led_subsystem`, `disk_top`: new ports and wiring.
- `disk_pkg`: `DISPLAY_MODE_WIDTH`, `SEQ_LENGTH`, `SEQ_OFFSETS`, `SEQ_HOLD_MS`.
- XDC: sw[8] V2, sw[9] T3, btnU T18.
- **`p_controller.sv` is unchanged** and still passes `tb_p_controller`.

### E1 special cases

| Case | Handling |
|---|---|
| Negative numbers on a 0–F display | Sign and magnitude: `bin_to_bcd` only ever receives the magnitude. A minus is drawn as segment G alone in the **leftmost** digit, and that digit is **un-blanked** only while the minus is shown, otherwise the sign would never appear. |
| Error larger than one revolution | Rounded first, then **limited to 999**, then the sign applied, so +x and −x show the same digits. |
| Error rounding | 360/2048 = 45/256 exactly, so degrees = (\|e\| × 45 + 128) >> 8. This is round-half-up, and it is exact for all 65,537 magnitudes (checked). |
| Command percentage | round(\|c\| × 100/255) = (\|c\| × 25,700 + 32,768) >> 16: a multiply and shift, no divider. Exact for all 256 values (checked). |
| "−0" | No minus sign when the rounded magnitude is 0 (e.g. an error of −2 counts = −0.35° shows "000"). |
| Mode 00 | Uses the MVP's own `display_selection` unchanged: degrees, or counts with sw[10] up. |
| Timing | Two pipeline registers: the products, then the selected value. The display is 20 ns late, which is invisible. |

### E2 special cases

| Case | Handling |
|---|---|
| The sequence | `SEQ_OFFSETS = {+512, +1024, +256, 0}` counts, i.e. +90°, +180°, +45°, back to start. These are relative to the setpoint when btnU was pressed, so it never asks for a multi-revolution move. They are stored in **counts, not degrees** (90 counts would be only 15.8°), in `disk_pkg` where they are easy to change. After the last entry it repeats from the first. |
| Start and stop | On the **rising edge** of debounced btnU. Using the level would toggle millions of times per press. |
| Hold time | (CLK_FREQ / 1000) × HOLD_MS = 100,000 × 2,000 = 2 × 10⁸ cycles. Dividing first avoids overflow: CLK_FREQ × HOLD_MS = 2 × 10¹¹ would overflow a 32-bit int. Because it's computed from CLK_FREQ, the 1 MHz testbench also gets 2 s. |
| Timer restart | The `downcounter` is reset when the sequence starts, so the first setpoint gets a full 2 s, not whatever was left on the counter. |
| btnR / btnL while running | Ignored: `setpoint_control.load = 1` gives the sequence the setpoint. |
| Stopping | `load` drops to 0 and the setpoint **holds its last value**: no jump. btnR/btnL then step from there. |
| Reset (btnC) | Stops the sequence. |
| Disarmed while running | The sequence keeps stepping the setpoint, but the motor stays off (the MVP's arm behaviour is unchanged). |
| P control stops short | The disk may read 359 at a 0° setpoint. That's the MVP's behaviour, not a sequence fault. |

---

## Step 2 — Design and simulate

| Testbench | What it checks | Result |
|---|---|---|
| **tb_display_mode_select** (E1, new) | Against a real-number model, round = floor(x + 0.5). Mode 00 = MVP (degrees and counts, blanking). Mode 01 for setpoints −2048 … 4096. Mode 10 for **every** error magnitude 0 … 65,535 at both signs: rounding, the 999 limit, minus sign and un-blanking, no "−0". Mode 11 for **every** command −255 … +255. | PASS (132,473 checks) |
| **tb_setpoint_sequence** (E2, new) | Stopped after reset. A press starts it at base + 512 with base captured. Each hold is exactly 2,000 cycles (1 kHz clock), in table order, and it wraps. A long press starts it only once. A second press stops it and it stays put. A restart begins at the first entry with a **full** hold and a new base. Reset stops it. | PASS (19 checks) |
| **tb_disk_top** (extended) | All MVP checks with sw[9:8] = 00 and btnU idle (AN4 blanking checked in mode 00). E1: modes 01, 10, 11 on the real loop, including the "−" segment pattern on AN4, a large negative error during a −180° move, and mode 00 restored. E2: LD10, the setpoint and disk settling (±8 counts) at each of the 4 steps and the wrap, btnR ignored while running, stop holds the setpoint, btnR works after. | PASS |
| MVP: tb_p_controller, tb_quad_decoder, tb_motor_drive, tb_debounce, tb_bin_to_bcd, tb_position_to_degrees, tb_display_selection | unchanged | PASS |

**I checked that the testbenches catch real bugs.** I put each of these bugs in on purpose, and the testbench failed every time:
- dropping the +128 rounding term
- showing "−0"
- dropping the +32,768 rounding term
- not restarting the hold timer
- using the btnU level instead of its edge

**What the testbenches would miss:** the real disk's friction and backlash, so actual settling may differ from the model. Real button bounce beyond the model. Timing, which is checked in Step 3.

Closed-loop log (tb_disk_top):
```
E1 mode 01 setpoint       display  090
E1 mode 10 error -2 cnt   display  000      (-0.35 deg rounds to 0: no minus)
E1 mode 11 command -4     display -002      (4/255 = 1.6% -> 2)
E1 mode 10 big step       display -159      (disk moving after a -180 deg step)
E2 step 0 (+90 deg)       setpoint     0  position     2  LD10 1
E2 step 1 (+180 deg)      setpoint   512  position   515  LD10 1
E2 step 2 (+45 deg)       setpoint  -256  position  -259  LD10 1
E2 step 3 (0 deg)         setpoint  -512  position  -514  LD10 1
E2 wraps to step 0        setpoint     0  position     2  LD10 1
E2 stopped (holds)        setpoint     0  position     2  LD10 0
```

**Vivado simulator (xsim 2026.1): all 10 testbenches PASS.** Run with `scripts/run_tests.py --stage final_e1_e2` on Nov 27, 2026. Full logs are in `evidence/final_e1_e2/`, summary in `summary.txt`. The closed-loop `tb_disk_top` simulated 22.1 s of disk motion and printed the same results as the log above.

```
PASS tb_quad_decoder        PASS tb_position_to_degrees
PASS tb_p_controller        PASS tb_disk_top
PASS tb_motor_drive         PASS tb_display_selection
PASS tb_debounce            PASS tb_display_mode_select (132473 checks)
PASS tb_bin_to_bcd          PASS tb_setpoint_sequence (19 checks)
```

### Annotated waveforms

**E2:** one full run of the sequence, btnR ignored while running, the stop holding the setpoint, and btnR working again (closed loop, disk model, Kp = 2).

![E2 waveform](E2_waveform.png)

**E1:** each display mode on the closed loop. The red trace is what the display shows (negative = minus sign lit). It follows the true error and the true command exactly, including the −151° error right after a −180° step.

![E1 waveform](E1_waveform.png)

**DO (from Vivado):** a screenshot of the RTL schematic (RTL Analysis → Open Elaborated Design → Schematic) showing `DISPLAY_MODE_SELECT` and `SETPOINT_SEQUENCE`.

---

## Step 3 — Build and check timing
| | MVP | Final (E1 + E2) | Change |
|---|---|---|---|
| Slice LUTs | 188 | 371 | **+183** |
| Slice Registers (FF) | 224 | 332 | **+108** |
| WNS (setup) | +1.486 ns | **+0.331 ns** | timing met |
| WHS (hold) | +0.109 ns | +0.076 ns | met |

(Vivado 2026.1, impl_1 with default strategy, xc7a35tcpg236-1, 10 ns clock.)

**Where the slack is:** the critical path is the MVP's own P-controller path, not the new E1/E2 logic: `setpoint_reg` → subtract → DSP multiply → ±255 compare → `p_action_reg` (9.6 ns, 11 logic levels). It existed in the MVP too, and its slack changed only because the placement changed with the extra logic. The E1 multiplies are pipelined (2 registers) and are not near the critical path. `p_controller.sv` may not be changed, so its path stays as it is. 0.33 ns positive slack meets the requirement.

**DO:** screenshot of the Project Summary (Utilization and Timing panels).

---

## Step 4 — Rig test and videos (to record)
Follow the MVP safety checklist. Keep sw[15] down while programming.

1. **E1_step4_modes.mp4**: Kp = 2, press btnR, then flip sw[9:8] through 00 → 01 → 10 → 11 while the disk moves and settles. Show a negative error and a reverse command (press btnL) with the minus sign.
2. **E2_step4_sequence.mp4**: press btnU. LD10 comes on, and the disk goes +90°, +180°, +45°, back, 2 s each. Press btnU again: it stops and holds.
3. **MVP_still_works.mp4**: sw[9:8] = 00, btnU idle. Hold position, step ±90°, counts mode on sw[10].

---

## Q&A preparation

**E1**
- **How do you show a negative number?** Sign and magnitude. `bin_to_bcd` gets the magnitude, and the leftmost digit (blank in degrees modes) is un-blanked and drawn as "−" (segment G only) when the sign is negative.
- **Why sign and magnitude?** `bin_to_bcd` only handles positive numbers, and rounding the magnitude and then applying the sign makes +x and −x round the same way.
- **How is the command scaled to a percentage, and how did you check the rounding?** It's (|c| × 25,700 + 32,768) >> 16, since 25,700/65,536 ≈ 100/255, and the +32,768 is +0.5 for rounding. `tb_display_mode_select` checks all 511 command values against round(|c| × 100/255).

**E2**
- **Why the edge of btnU, not its level?** A press lasts about 100 ms, which is 10⁷ clock cycles. Using the level would toggle the sequence on every one of them.
- **How is the hold time calculated, and can it overflow?** It's (CLK_FREQ / 1000) × 2000 = 2 × 10⁸ cycles. Dividing first keeps it inside a 32-bit int; CLK_FREQ × 2000 = 2 × 10¹¹ would not fit.
- **What happens to the setpoint when the sequence stops?** `setpoint_control` stops loading it and holds the last value, so there's no jump, and btnR/btnL continue from there.

---

*E4 (PI control) was replaced by E1 + E2. Its files are kept for reference in `archive_E4/` and are not part of the design.*
