"""Run every self-checking testbench with Vivado's simulator (xvlog/xelab/xsim).

Usage (from the repository folder):
    python scripts/run_tests.py                  # all 10 testbenches
    python scripts/run_tests.py tb_disk_top      # just one
Logs and summary.txt go to evidence/<stage>/ (default stage: final).
Set VIVADO_BIN if Vivado is not in a standard place.
"""
import argparse
import os
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
def _find_vivado_bin():
    """VIVADO_BIN if set, else the first standard Windows install found."""
    if os.environ.get('VIVADO_BIN'):
        return Path(os.environ['VIVADO_BIN'])
    for version in ('2026.1', '2025.2', '2025.1', '2024.2'):
        for base in (r'C:\AMDDesignTools', r'C:\Xilinx'):
            candidate = Path(base) / version / 'Vivado' / 'bin'
            if candidate.exists():
                return candidate
    sys.exit('Vivado not found: set VIVADO_BIN to your Vivado bin folder, '
             'e.g. C:/AMDDesignTools/2026.1/Vivado/bin')


BIN = _find_vivado_bin()
TESTS = ['tb_quad_decoder', 'tb_p_controller', 'tb_motor_drive', 'tb_debounce',
         'tb_bin_to_bcd', 'tb_position_to_degrees', 'tb_disk_top',
         'tb_display_selection', 'tb_display_mode_select', 'tb_setpoint_sequence']

def run(tool, args, cwd, log):
    with log.open('w', encoding='utf-8') as out:
        result = subprocess.run([str(BIN / (tool + '.bat')), *args], cwd=cwd,
                                stdout=out, stderr=subprocess.STDOUT,
                                stdin=subprocess.DEVNULL)
    data = log.read_text(encoding='utf-8', errors='replace')
    if result.returncode or re.search(r'(?m)^ERROR:', data):
        print(data[-6000:], flush=True)
        raise RuntimeError(f'{tool} failed: {log}')
    return data

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--stage', default='final')
    parser.add_argument('tests', nargs='*')
    args = parser.parse_args()
    folder = ROOT / 'evidence' / args.stage
    folder.mkdir(parents=True, exist_ok=True)
    rtl = [ROOT / 'rtl/disk_pkg.sv'] + sorted(
        p for p in (ROOT / 'rtl').glob('*.sv') if p.name != 'disk_pkg.sv')
    tests = args.tests or TESTS
    sources = rtl + [ROOT / 'tb' / (t + '.sv') for t in tests]
    run('xvlog', ['--sv', *map(str, sources)], folder, folder / 'compile.log')
    summaries = []
    failed = False
    for test in tests:
        run('xelab', ['--debug', 'typical', test, '-s', test + '_sim'],
            folder, folder / (test + '_elaborate.log'))
        batch = folder / (test + '.tcl')
        commands = ''
        if test == 'tb_quad_decoder':
            commands = ('open_vcd decoder.vcd\n'
                        'log_vcd /tb_quad_decoder/clk /tb_quad_decoder/reset '
                        '/tb_quad_decoder/a /tb_quad_decoder/b '
                        '/tb_quad_decoder/position\n')
        batch.write_text(commands + 'run all\n' +
                         ('close_vcd\n' if commands else '') + 'quit\n')
        data = run('xsim', [test + '_sim', '-tclbatch', batch.name],
                   folder, folder / (test + '.log'))
        passed = f'PASS {test}' in data and not re.search(r'\bFAIL\b|\bFATAL\b', data)
        line = ('PASS ' if passed else 'FAIL ') + test
        summaries.append(line)
        print(line, flush=True)
        if not passed:
            print(data[-4000:], flush=True)
            failed = True
    (folder / 'summary.txt').write_text('\n'.join(summaries) + '\n')
    return int(failed)

if __name__ == '__main__':
    sys.exit(main())
