# Create the Vivado project for the ENEL 453 Final Project (E1 + E2) from the
# sources in this repository. Nothing in the project points outside the repo,
# so it works wherever you cloned it (spaces in the path are fine).
#
# From the Vivado GUI:   Tcl Console ->  source <repo>/scripts/create_project.tcl
# From a terminal:       vivado -mode batch -source scripts/create_project.tcl
#
# The project is created in <repo>/vivado/Final_Project.xpr (git ignores it).
# Re-running the script deletes and recreates that folder.

set root [file normalize [file join [file dirname [info script]] ..]]
set proj_dir [file join $root vivado]

create_project -force Final_Project $proj_dir -part xc7a35tcpg236-1

# Design sources: disk_pkg first (every other file imports it).
set pkg [file join $root rtl disk_pkg.sv]
set rtl [list $pkg]
foreach f [lsort [glob [file join $root rtl *.sv]]] {
    if {$f ne $pkg} { lappend rtl $f }
}
add_files -norecurse $rtl

add_files -fileset constrs_1 -norecurse [file join $root constraints disk_basys3.xdc]

add_files -fileset sim_1 -norecurse [lsort [glob [file join $root tb *.sv]]]

set_property top disk_top [get_filesets sources_1]
set_property top tb_disk_top [get_filesets sim_1]
set_property -name {xsim.simulate.runtime} -value {all} -objects [get_filesets sim_1]
update_compile_order -fileset sources_1
update_compile_order -fileset sim_1

puts "PROJECT_READY [file join $proj_dir Final_Project.xpr]"
