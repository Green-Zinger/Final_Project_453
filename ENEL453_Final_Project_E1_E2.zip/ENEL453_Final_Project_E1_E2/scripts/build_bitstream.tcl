# Build the Basys3 image from the verified local RTL and pin constraints.
set root [file normalize [file join [file dirname [info script]] ..]]
set out [file join $root output]
file mkdir $out
set_param general.maxThreads 4
create_project -in_memory -part xc7a35tcpg236-1
read_verilog -sv [file join $root rtl disk_pkg.sv]
foreach source [lsort [glob [file join $root rtl *.sv]]] {
    if {[file tail $source] ne "disk_pkg.sv"} {
        read_verilog -sv $source
    }
}
read_xdc [file join $root constraints disk_basys3.xdc]
synth_design -top disk_top -part xc7a35tcpg236-1
opt_design
place_design
route_design
report_utilization -file [file join $out disk_top_utilization.rpt]
report_timing_summary -file [file join $out disk_top_timing.rpt]
report_drc -file [file join $out disk_top_drc.rpt]
write_checkpoint -force [file join $out disk_top_routed.dcp]
write_bitstream -force [file join $out disk_top.bit]
puts "BITSTREAM_READY [file join $out disk_top.bit]"
exit
