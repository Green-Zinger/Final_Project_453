`timescale 1ns / 1ps
//==============================================================================
// Testbench: tb_display_mode_select   (Enhancement E1, self-checking)
//
// Checks display_mode_select against an independent model written with
// real-number arithmetic (round(x) = floor(x + 0.5)):
//   1. mode 00 is exactly the MVP display (display_selection): degrees, and
//      counts with sw[10] up, leftmost digit blanked in degrees only
//   2. mode 01: the setpoint in degrees, for every setpoint in one revolution
//      and for negative and multi-revolution setpoints
//   3. mode 10: the error (setpoint - position) in degrees for EVERY error
//      magnitude 0 ... 65,535, positive and negative: rounded magnitude,
//      limited to 999, minus sign (and leftmost digit un-blanked) only when
//      negative and not zero; +e and -e show the same digits
//   4. mode 11: the command as a percentage for EVERY command -255 ... +255:
//      correctly rounded, minus for reverse, no "-0"
// Prints PASS or FAIL, with the number of checks.
//==============================================================================
module tb_display_mode_select;
    import disk_pkg::*;

    logic clk = 0, reset = 1, counts_mode = 0;
    logic [1:0] mode = 0;
    logic signed [15:0] position = 0, setpoint = 0;
    logic signed [8:0]  command = 0;
    logic [15:0] display_value;
    logic [3:0]  digit_blank;
    logic        minus;
    int checks = 0, errors = 0;

    display_mode_select DUT (
        .clk(clk), .reset(reset), .mode(mode), .counts_mode(counts_mode),
        .position(position), .setpoint(setpoint), .command(command),
        .display_value(display_value), .digit_blank(digit_blank), .minus(minus)
    );

    always #5 clk = ~clk;

    function automatic int round_real(real x);
        return $rtoi($floor(x + 0.5));
    endfunction

    // Apply inputs, wait for the 2-stage pipeline, compare.
    task automatic check(int want_value, bit want_minus, string what);
        logic [3:0] want_blank;
        repeat (3) @(negedge clk);
        want_blank = want_minus ? 4'b0000 : 4'b1000;
        checks++;
        if (display_value !== 16'(want_value) || minus !== want_minus
            || digit_blank !== want_blank) begin
            errors++;
            if (errors <= 10)
                $display("FAIL %s: shows %0d minus %b blank %b; expected %0d minus %b blank %b",
                         what, display_value, minus, digit_blank,
                         want_value, want_minus, want_blank);
        end
    endtask

    initial begin
        int e, deg, pct, p, s;
        repeat (3) @(negedge clk);
        reset = 0;

        // 1. Mode 00 = MVP display.
        mode = 2'b00;
        for (int k = 0; k < 6; k++) begin
            p = (k == 0) ? 0 : (k == 1) ? 512 : (k == 2) ? -512 : (k == 3) ? 2047
              : (k == 4) ? 3000 : -1;
            position = p; counts_mode = 0;
            check(((p % 2048 + 2048) % 2048) * 360 / 2048, 0, $sformatf("mode 00 degrees, position %0d", p));
            counts_mode = 1;
            repeat (3) @(negedge clk);
            checks++;
            if (display_value !== 16'((p % 2048 + 2048) % 2048) || digit_blank !== 4'b0000 || minus) begin
                errors++;
                $display("FAIL mode 00 counts, position %0d: shows %0d blank %b", p, display_value, digit_blank);
            end
        end
        counts_mode = 0;

        // 2. Mode 01 = setpoint in degrees.
        mode = 2'b01; position = 0;
        for (s = -2048; s <= 4096; s += 7) begin
            setpoint = s;
            check(((s % 2048 + 2048) % 2048) * 360 / 2048, 0, $sformatf("mode 01 setpoint %0d", s));
        end

        // 3. Mode 10 = error in degrees, every magnitude, both signs.
        mode = 2'b10;
        for (e = 0; e <= 65535; e++) begin
            deg = round_real(e * 360.0 / 2048.0);
            if (deg > 999) deg = 999;
            // positive error: setpoint above position
            setpoint = 16'(e / 2);  position = 16'(e / 2 - e);      // setpoint - position = e
            check(deg, 0, $sformatf("mode 10 error +%0d", e));
            // negative error: same magnitude, minus sign unless it rounds to 0
            setpoint = 16'(e / 2 - e); position = 16'(e / 2);       // setpoint - position = -e
            check(deg, deg != 0, $sformatf("mode 10 error -%0d", e));
        end

        // 4. Mode 11 = command percentage, every command.
        mode = 2'b11;
        for (int c = -255; c <= 255; c++) begin
            command = 9'(c);
            pct = round_real((c < 0 ? -c : c) * 100.0 / 255.0);
            check(pct, (c < 0) && (pct != 0), $sformatf("mode 11 command %0d", c));
        end

        if (errors == 0) $display("PASS tb_display_mode_select (%0d checks)", checks);
        else             $display("FAIL tb_display_mode_select: %0d errors in %0d checks", errors, checks);
        $finish;
    end
endmodule
