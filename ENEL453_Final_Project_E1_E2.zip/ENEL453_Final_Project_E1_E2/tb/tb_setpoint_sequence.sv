`timescale 1ns / 1ps
//==============================================================================
// Testbench: tb_setpoint_sequence   (Enhancement E2, self-checking)
//
// Runs setpoint_sequence with CLK_FREQ = 1 kHz, so HOLD_MS = 2000 gives
// exactly 2,000 clock cycles per setpoint (the same formula as on the board).
// Checks
//   1. after reset: stopped
//   2. a press starts it: running = 1, the first setpoint is base + 512, and
//      base is the setpoint at the moment of the press
//   3. every setpoint is held for exactly HOLD cycles, in table order
//      (+512, +1024, +256, +0), and it wraps around to the first again
//   4. holding btnU down for a long time starts it only once (edge, not level)
//   5. a second press stops it; it then holds still (no more steps)
//   6. restarting begins at the FIRST setpoint and the first hold is a FULL
//      hold time, even if it was stopped halfway through a hold
//   7. base is captured at each start (a new start from a different setpoint)
//   8. reset stops it
// Prints PASS or FAIL, with the number of checks.
//==============================================================================
module tb_setpoint_sequence;
    import disk_pkg::*;

    localparam int CLK_FREQ = 1000;
    localparam int HOLD     = (CLK_FREQ / 1000) * SEQ_HOLD_MS;   // 2,000 cycles

    logic clk = 0, reset = 1, start_stop = 0;
    logic signed [15:0] setpoint_now = 16'sd100;
    logic running;
    logic signed [15:0] sequence_setpoint;
    int checks = 0, errors = 0;

    setpoint_sequence #(.CLK_FREQ(CLK_FREQ), .HOLD_MS(SEQ_HOLD_MS)) DUT (
        .clk(clk), .reset(reset), .start_stop(start_stop),
        .setpoint_now(setpoint_now), .running(running),
        .sequence_setpoint(sequence_setpoint)
    );

    always #5 clk = ~clk;

    task automatic expect_eq(int got, int want, string what);
        checks++;
        if (got != want) begin
            errors++;
            $display("FAIL %s: got %0d, expected %0d", what, got, want);
        end
    endtask

    task automatic press(int cycles = 5);
        @(negedge clk) start_stop = 1;
        repeat (cycles) @(negedge clk);
        start_stop = 0;
        @(negedge clk);
    endtask

    // Count clock cycles until sequence_setpoint changes (or a limit).
    task automatic cycles_to_change(output int n);
        logic signed [15:0] was;
        was = sequence_setpoint;
        n = 0;
        while (sequence_setpoint === was && n < 3 * HOLD) begin
            @(negedge clk); n++;
        end
    endtask

    initial begin
        int n, base;
        repeat (3) @(negedge clk);
        reset = 0; @(negedge clk);

        // 1. Stopped after reset
        expect_eq(running, 0, "stopped after reset");

        // 2 + 4. Start with a LONG press (held for 5 hold times' worth? no:
        //        500 cycles): starts once, does not toggle back.
        base = 100;
        press(500);
        expect_eq(running, 1, "running after a long press");
        expect_eq(sequence_setpoint, base + SEQ_OFFSETS[0], "first setpoint = base + 512");

        // 3. Each step held exactly HOLD cycles, in order, then wraps.
        //    (The first hold already used up ~501 cycles during the press.)
        cycles_to_change(n);
        expect_eq(sequence_setpoint, base + SEQ_OFFSETS[1], "second setpoint = base + 1024");
        for (int k = 2; k <= SEQ_LENGTH + 1; k++) begin
            cycles_to_change(n);
            expect_eq(n, HOLD, $sformatf("hold time before step %0d (cycles)", k % SEQ_LENGTH));
            expect_eq(sequence_setpoint, base + SEQ_OFFSETS[k % SEQ_LENGTH],
                      $sformatf("step %0d = base + %0d", k % SEQ_LENGTH, SEQ_OFFSETS[k % SEQ_LENGTH]));
        end

        // 5. Stop halfway through a hold; it then stays put.
        repeat (HOLD / 2) @(negedge clk);
        press();
        expect_eq(running, 0, "stopped by the second press");
        n = sequence_setpoint;
        repeat (3 * HOLD) @(negedge clk);
        expect_eq(running, 0, "stays stopped");

        // 6 + 7. Restart from a different setpoint: first entry, full hold.
        setpoint_now = -16'sd700;  base = -700;
        press();
        expect_eq(running, 1, "running again");
        expect_eq(sequence_setpoint, base + SEQ_OFFSETS[0], "restart: first setpoint, new base");
        cycles_to_change(n);
        // The press itself takes a few cycles, so the rest of the first hold is
        // HOLD minus those few cycles. Without the timer restart it would be
        // about HOLD / 2 (what was left when it was stopped).
        checks++;
        if (n < HOLD - 10 || n > HOLD) begin
            errors++;
            $display("FAIL restart: first hold %0d cycles, expected a full hold (%0d)", n, HOLD);
        end
        expect_eq(sequence_setpoint, base + SEQ_OFFSETS[1], "restart: second setpoint");

        // 8. Reset stops it.
        reset = 1; @(negedge clk); reset = 0; @(negedge clk);
        expect_eq(running, 0, "reset stops it");

        if (errors == 0) $display("PASS tb_setpoint_sequence (%0d checks)", checks);
        else             $display("FAIL tb_setpoint_sequence: %0d errors in %0d checks", errors, checks);
        $finish;
    end
endmodule
