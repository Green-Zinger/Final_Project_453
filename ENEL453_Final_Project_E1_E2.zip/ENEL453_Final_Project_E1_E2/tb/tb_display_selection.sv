`timescale 1ns / 1ps
//==============================================================================
// Testbench: tb_display_selection
// Exhaustively checks every signed 16-bit position in both modes against an
// independent modulo/division oracle, including -1, wrap and signed endpoints.
// Checks all four digit-blank bits as well as the selected binary value.
//==============================================================================
module tb_display_selection;
    import disk_pkg::*;
    logic signed [POSITION_WIDTH-1:0] position;
    logic counts_mode;
    logic [15:0] display_value;
    logic [3:0] digit_blank;
    int errors = 0;
    int wrapped, expected;

    display_selection DUT (
        .position(position), .counts_mode(counts_mode),
        .display_value(display_value), .digit_blank(digit_blank)
    );

    initial begin
        for (int p = -(2**(POSITION_WIDTH-1)); p < 2**(POSITION_WIDTH-1); p++) begin
            position = POSITION_WIDTH'(p);
            wrapped = ((p % COUNTS_PER_REV) + COUNTS_PER_REV) % COUNTS_PER_REV;
            for (int mode = 0; mode < 2; mode++) begin
                counts_mode = 1'(mode);
                expected = mode ? wrapped : wrapped * DEGREES_PER_REV / COUNTS_PER_REV;
                #1;
                if (display_value !== 16'(expected) ||
                    digit_blank !== (mode ? 4'b0000 : 4'b1000)) begin
                    if (errors < 10)
                        $display("FAIL p=%0d mode=%0d value=%0d expected=%0d blank=%b",
                                 p, mode, display_value, expected, digit_blank);
                    errors++;
                end
            end
        end
        if (errors == 0) $display("PASS tb_display_selection (131072 cases)");
        else $display("FAIL tb_display_selection: %0d errors", errors);
        $finish;
    end
endmodule
